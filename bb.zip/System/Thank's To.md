</> 𝗕𝗨𝗬 𝗦𝗖𝗥𝗜𝗣𝗧 𝗡𝗢 𝗘𝗡𝗖 : 
 - Telegram (t.me/FixzzCok)
 - Whatsapp ( https://wa.me/6285835692106 ) 
   
</> 𝗙𝗢𝗟𝗟𝗢𝗪 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 𝗗𝗘𝗩 :
 - FyzzOffcial ( https://whatsapp.com/channel/0029VbBFQNb17En3MAIHaU3R ) 

# 𝗧𝗛𝗔𝗡𝗞𝗦 𝗧𝗢 :
Allah Swt 
Ibu [ Support & Ratuku ]
Ayah [ Support & Rajaku ]
FyzzModss [ Developer ]
Muachhhhvebebb [ Owner ]
Rindoucrash [ Owner ]
kenzzmodegod [ Owner ]
KinkAzet [ Owner ]
Family [ Best Support ]

[ ! ] 𝗡𝗢𝗧𝗘 : terima kasih telah membeli script ini, diharapkan make dengan secara bijak dan tidak merugikan pihak yang berwajib
