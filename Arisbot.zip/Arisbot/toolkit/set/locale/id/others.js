let infos = Data.infos.others ??= {};

infos.noDetectViewOnce = "Ups, sepertinya saya tidak dapat mendeteksi pesan 1x lihat yang dikirim oleh orang tersebut!"

/*!-======[ Read More ]======-!*/
infos.readMore = "͏".repeat(3646)