let infos = Data.infos.others ??= {};

infos.noDetectViewOnce = "Oops, I can’t seem to detect the view-once message sent by that person!"


/*!-======[ Read More ]======-!*/
infos.readMore = "͏".repeat(3646)