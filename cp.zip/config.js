module.exports = {
  BOT_TOKEN: "7994524600:AAG-275XexVQjeK9wE3yqRNPBARrD9fhLGg",
  OWNER_ID: ["8007081995"],
};
/*/━━━━━━━━━━━━━━━━━━━━━━━━  
   🔥 SPECTRA WRAITH 🔥
━━━━━━━━━━━━━━━━━━━━━━━━━  
Developer: Kilzz || Hudzz
Telegram: @KilzzWatafak2 || @HudzzWTF
Version: 1.3

⚠️ 𝗪𝗔𝗥𝗡𝗜𝗡𝗚! ⚠️  
Script ini menggunakan database.  
Jika token Anda 
tidak terdaftar di database,  
Script tidak akan berjalan!  
Pastikan token Anda sudah terdaftar sebelum menggunakan Sc Ini
Script Ini Juga Sudah Memakai Enc Invis Anti Webcrack Yak! Jadi Aman Dari Kang Crack Sc / Kang Sebar
*/