const fs = require('fs')

global.botname = "Nted Crasher"
global.version = "? ??"
global.owner = "6289510019072"
global.footer = "NtedSempak"
global.idch = "120363393940866504@newsletter"
global.packname = "Nted Inflow"

//Global Thumb
global.thumb = "https://files.catbox.moe/h6cnl8.mp4"

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
