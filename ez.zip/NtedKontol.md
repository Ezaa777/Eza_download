# CONTACT OWNER
[ https://62882018213410 ]
[ https://6289510019072 ]
[ https://youtube.com/@NtedOfficial-New ]
[ https://t.me/NtedCrasher ]

# Thanks To:
Nted [ Owner Script ]
Kontol [ Kekasihnya Nted Yang Selalu Menemani Nted ]
Raflie [ Friend Nted ]
Rapli [ Best Friends ]
Kaizi [ Abang Tercinta ]
Om Osaka [ Abng Tercinta ]
Hamz Dev XA [ Kawan Terbaik ]
Daffa Dev [ Sensei Majuk ]
Dapz [ Sensei Duit Mulu ]
DrayXD [ Om Dray Imoet ]
Justin Offical [ Om Tamvan ]
Rappip Improve [ Nted Nak Jadi Dia ]
Depay [ Teman Terbaik Nted ]
Tama Ryuichi [ Orang Keren ]
Kayzen [ Friend Nted ]
Erlangga [ Waduh Mau Sepuh ]
Lezz [ Yang Bantu Nted 🗿 ]
Hanz [ Admin Terbaik Nted ]
Raflie [ Teman Nted Paling The Best ]

# Patner Tercinta Nted
SanzzXhunTer [ Hacker Jir ]
RaffMewaa [ MASUKIN AJA ]
Dilxz Is Here [ INI LAGI DEV ]
All PT Terbaik Nted [ All PT Pokoknya ]

